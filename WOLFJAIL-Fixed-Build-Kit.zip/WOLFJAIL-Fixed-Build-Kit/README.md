# WOLFJAIL 0.1.0 — corrected build kit

This is a harmless SwiftUI interface prototype. It does not jailbreak iPadOS, install packages, gain elevated privileges, or bypass device security.

## Corrected build setup

This version replaces the earlier manually generated Xcode project file with a corrected project configuration and a more diagnostic GitHub Actions workflow.

1. Back up your existing GitHub repository.
2. Upload/replace the files from this ZIP at the repository root. Ensure `.github/workflows/build-unsigned-ipa.yml` is included.
3. The repository root must contain `WOLFJAIL.xcodeproj`, `WOLFJAIL/`, and `.github/`.
4. In Actions, run **Build WOLFJAIL unsigned IPA**.
5. Download the `WOLFJAIL-unsigned-IPA` artifact from a successful run.

The workflow compiles on a hosted macOS runner and packages an **unsigned** IPA archive. It is not directly installable until signed with a valid Apple development identity and provisioning profile. Never upload Apple passwords, certificates, or private keys to the repository or chat.
