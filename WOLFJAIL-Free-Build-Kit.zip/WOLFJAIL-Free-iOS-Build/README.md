# WOLFJAIL 0.1.0 — free build setup

This is a SwiftUI interface prototype. It does not jailbreak iPadOS, install packages, gain elevated privileges, or bypass device security.

## What this package does

- Provides an Xcode project for an iOS/iPadOS app.
- Includes a GitHub Actions workflow that uses a hosted macOS runner to compile the app and package an **unsigned** `.ipa` archive.
- Uploads the archive as a downloadable workflow artifact.

## Important: unsigned is not installable

The workflow produces a valid IPA-style archive containing `Payload/WOLFJAIL.app`, but it is **not signed**. iPadOS will not install it as a normal app until it is signed with a valid Apple development/distribution identity and matching provisioning profile. Do not upload Apple passwords, certificates, or private keys into chat.

## Run the free build workflow

1. Create a GitHub repository. Public repositories generally have free standard hosted-runner minutes; check GitHub's current usage limits before relying on this.
2. Upload the contents of this folder to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build unsigned WOLFJAIL IPA**.
5. Choose **Run workflow**.
6. When it finishes, open the run and download the `WOLFJAIL-unsigned-IPA` artifact.

A public repository makes its source visible to everyone. If you need the source to stay private, check the current included Actions minutes and macOS runner billing for your GitHub plan before running it.

## Project details

- Minimum deployment target: iOS/iPadOS 16.0
- Bundle identifier: `com.example.wolfjail` (change before signing)
- Interface: Home, Device, Packages preview, Settings
