import SwiftUI
import UIKit

struct ContentView: View {
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView()
                .tabItem { Label("Home", systemImage: "square.grid.2x2") }
                .tag(0)

            DeviceView()
                .tabItem { Label("Device", systemImage: "ipad") }
                .tag(1)

            PackagesView()
                .tabItem { Label("Packages", systemImage: "shippingbox") }
                .tag(2)

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(3)
        }
        .tint(.cyan)
    }
}

struct DashboardView: View {
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WOLFJAIL").font(.largeTitle.bold())
                        Text("Device workspace").foregroundStyle(.secondary)
                        Label("Interface preview", systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                    .padding(.vertical, 10)
                }
                Section("Workspace") {
                    Label("Device information", systemImage: "ipad")
                    Label("Package catalog preview", systemImage: "shippingbox")
                    Label("Preferences", systemImage: "slider.horizontal.3")
                }
                Section {
                    Text("This is a UI prototype. It does not jailbreak the device, gain elevated privileges, install packages, or modify iPadOS security settings.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Home")
        }
    }
}

struct DeviceView: View {
    var body: some View {
        NavigationStack {
            List {
                LabeledContent("Device", value: UIDevice.current.model)
                LabeledContent("System", value: UIDevice.current.systemName)
                LabeledContent("Version", value: UIDevice.current.systemVersion)
                LabeledContent("Device name", value: UIDevice.current.name)
                LabeledContent("Chip", value: "Not available to this app")
                Text("This screen displays basic public device information only. It cannot determine jailbreak compatibility or exploitability.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .navigationTitle("Device")
        }
    }
}

struct PackagesView: View {
    private let packages = [
        ("Example Theme", "A sample theme entry for the interface."),
        ("Demo Widget", "A placeholder widget entry."),
        ("Sample Utility", "A non-installable catalog example.")
    ]

    var body: some View {
        NavigationStack {
            List(packages, id: \.0) { item in
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.0).font(.headline)
                    Text(item.1).font(.subheadline).foregroundStyle(.secondary)
                    Text("PREVIEW ONLY").font(.caption2.bold()).foregroundStyle(.orange)
                }
                .padding(.vertical, 4)
            }
            .navigationTitle("Packages")
        }
    }
}

struct SettingsView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("About") {
                    LabeledContent("App", value: "WOLFJAIL")
                    LabeledContent("Version", value: "0.1.0")
                }
                Section("Safety") {
                    Text("WOLFJAIL is currently an informational SwiftUI prototype. Package entries are examples and cannot be installed.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Settings")
        }
    }
}
