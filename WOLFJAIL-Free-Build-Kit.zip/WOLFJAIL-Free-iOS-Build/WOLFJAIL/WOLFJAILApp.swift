import SwiftUI

@main
struct WOLFJAILApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
